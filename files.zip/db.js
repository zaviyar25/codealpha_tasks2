/**
 * Database Layer - SQL Injection Prevention (Week 5)
 * Uses prepared statements / parameterized queries exclusively
 */

const sqlite3 = require('sqlite3');
const { open } = require('sqlite');

let db;

async function getDB() {
  if (!db) {
    db = await open({ filename: ':memory:', driver: sqlite3.Database });
    await db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);
  }
  return db;
}

// ✅ SAFE: Parameterized query - prevents SQL injection
async function getUserByUsername(username) {
  const database = await getDB();
  // The ? placeholder is NEVER concatenated into SQL string
  return database.get('SELECT id, username FROM users WHERE username = ?', [username]);
}

// ✅ SAFE: Parameterized query for login
async function validateUser(username, passwordHash) {
  const database = await getDB();
  return database.get(
    'SELECT id, username FROM users WHERE username = ? AND password_hash = ?',
    [username, passwordHash]
  );
}

// ❌ VULNERABLE (for demonstration only - NEVER use this):
// async function unsafeLogin(username) {
//   const query = `SELECT * FROM users WHERE username = '${username}'`;
//   // Attacker input: ' OR '1'='1 → bypasses auth!
// }

// ✅ SAFE: Insert with parameterized query
async function createUser(username, passwordHash) {
  const database = await getDB();
  return database.run(
    'INSERT INTO users (username, password_hash) VALUES (?, ?)',
    [username, passwordHash]
  );
}

module.exports = { getUserByUsername, validateUser, createUser };
