/**
 * Cybersecurity Internship - Weeks 4-6
 * Secured Express.js API Server
 * Author: Cybersecurity Intern
 * Date: April 2026
 */

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const csrf = require('csurf');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const path = require('path');

const app = express();

// ─── 1. SECURITY HEADERS (Week 4) ──────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  hsts: {
    maxAge: 31536000,         // 1 year in seconds
    includeSubDomains: true,
    preload: true,
  },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  noSniff: true,
  xssFilter: true,
  hidePoweredBy: true,
}));

// ─── 2. CORS CONFIGURATION (Week 4) ────────────────────────────────────────
const allowedOrigins = [
  'https://yourdomain.com',
  'https://app.yourdomain.com',
];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS policy violation: ${origin} is not allowed`));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key'],
  credentials: true,
  maxAge: 86400,
}));

// ─── 3. RATE LIMITING (Week 4) ─────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 5,                      // strict: 5 attempts per window
  message: { error: 'Too many login attempts. Account temporarily locked.' },
  skipSuccessfulRequests: true,
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,        // 1 minute
  max: 30,
  message: { error: 'API rate limit exceeded.' },
});

app.use(globalLimiter);

// ─── 4. PARSERS ─────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

// ─── 5. LOGGING ─────────────────────────────────────────────────────────────
app.use(morgan('combined'));

// ─── 6. API KEY AUTHENTICATION MIDDLEWARE (Week 4) ─────────────────────────
const validateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  const validKeys = process.env.API_KEYS?.split(',') || ['dev-key-12345'];
  if (!apiKey || !validKeys.includes(apiKey)) {
    return res.status(401).json({ error: 'Invalid or missing API key' });
  }
  next();
};

// ─── 7. CSRF PROTECTION (Week 5) ───────────────────────────────────────────
const csrfProtection = csrf({ cookie: { httpOnly: true, secure: true } });

// ─── 8. ROUTES ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Auth routes (rate-limited strictly)
app.post('/api/auth/login', authLimiter, async (req, res) => {
  const { username, password } = req.body;
  // Prepared statement approach (see db.js for full implementation)
  // Using parameterized queries prevents SQLi
  res.json({ message: 'Login endpoint active' });
});

// Protected API routes (API key + rate limit)
app.use('/api/v1', validateApiKey, apiLimiter);

app.get('/api/v1/data', (req, res) => {
  res.json({ data: 'Protected resource', user: req.headers['x-api-key'] });
});

// CSRF-protected form route
app.get('/form', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

app.post('/form/submit', csrfProtection, (req, res) => {
  res.json({ message: 'Form submitted securely' });
});

// ─── 9. ERROR HANDLING ──────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ error: 'CSRF token validation failed' });
  }
  if (err.message?.includes('CORS')) {
    return res.status(403).json({ error: 'CORS policy violation' });
  }
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`[${new Date().toISOString()}] Secured server running on port ${PORT}`);
});

module.exports = app;
