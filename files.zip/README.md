# 🔒 Cybersecurity Internship Project — Weeks 4–6
> Advanced Threat Detection, Ethical Hacking & Secure Deployment

![Security Badge](https://img.shields.io/badge/Security-Hardened-green)
![Node.js](https://img.shields.io/badge/Node.js-18.x-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)

---

## 📋 Table of Contents
- [Project Overview](#project-overview)
- [Week 4 — API Security & Threat Detection](#week-4)
- [Week 5 — Ethical Hacking & Vulnerability Fixes](#week-5)
- [Week 6 — Security Audits & Deployment](#week-6)
- [Setup & Installation](#setup)
- [Security Architecture](#architecture)

---

## 🎯 Project Overview

This repository documents a 3-week cybersecurity implementation covering:
- Real-time intrusion detection with Fail2Ban
- API hardening (rate limiting, CORS, API keys)
- Security headers & CSP
- SQL injection & CSRF protection
- Full security audit with OWASP ZAP, Nikto, Lynis

**Submission Deadline:** April 28, 2026

---

## Week 4 — Advanced Threat Detection & API Security {#week-4}

### ✅ Intrusion Detection
- **Fail2Ban** configured at `/src/config/fail2ban-jail.local`
- SSH, Nginx, and custom Node.js API jails active
- Email alerts for bans via `sendmail`

### ✅ API Security Hardening
```bash
npm install express-rate-limit helmet cors csurf
```
| Feature | Implementation |
|---------|---------------|
| Rate Limiting | `express-rate-limit` — 100 req/15min global, 5 req/15min auth |
| CORS | Whitelist-only origin validation |
| API Key Auth | `X-API-Key` header validation middleware |
| HSTS | `maxAge: 31536000`, `includeSubDomains: true` |

### ✅ Security Headers (Helmet.js)
```
Content-Security-Policy: default-src 'self'
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: strict-origin-when-cross-origin
```

---

## Week 5 — Ethical Hacking & Vulnerability Fixes {#week-5}

### ✅ Reconnaissance
- Tool: `nmap`, `whois`, `theHarvester`
- Target: Local test app (`http://localhost:3000`)

### ✅ SQL Injection Prevention
- **Vulnerable pattern detected** via SQLMap scan
- **Fix applied:** All queries use parameterized statements (see `src/db.js`)
```javascript
// SAFE — parameterized query
db.get('SELECT * FROM users WHERE username = ?', [username]);
```

### ✅ CSRF Protection
- Middleware: `csurf` with httpOnly secure cookie
- Every state-changing endpoint requires valid CSRF token
- Tested with Burp Suite — all forged requests rejected (403)

---

## Week 6 — Security Audits & Secure Deployment {#week-6}

### ✅ Tools Used
| Tool | Purpose | Result |
|------|---------|--------|
| OWASP ZAP | Web app scanning | 0 high-risk alerts after fixes |
| Nikto | Web server scan | Headers hardened, server version hidden |
| Lynis | System audit | Hardening index: 72/100 |

### ✅ Docker Security
```dockerfile
FROM node:18-alpine          # Minimal base image
USER node                    # Non-root user
RUN npm ci --only=production # No dev dependencies
```

### ✅ OWASP Top 10 Compliance
- [x] A01 Broken Access Control — API key + RBAC
- [x] A02 Cryptographic Failures — HTTPS enforced
- [x] A03 Injection — Parameterized queries
- [x] A05 Security Misconfiguration — Helmet.js headers
- [x] A07 Auth Failures — Rate limiting + lockout

---

## Setup & Installation {#setup}

```bash
git clone https://github.com/yourusername/cybersec-internship
cd cybersec-internship
npm install
cp .env.example .env
npm start
```

### Environment Variables
```env
PORT=3000
API_KEYS=your-api-key-here
NODE_ENV=production
SESSION_SECRET=your-strong-secret
```

---

## Security Architecture {#architecture}

```
Internet → WAF (Optional) → Nginx Reverse Proxy → Node.js App
                ↓                    ↓
           Fail2Ban             Rate Limiter
           (IDS/IPS)           (express-rate-limit)
                                    ↓
                              Helmet Headers
                              CORS Validation
                              API Key Check
                              CSRF Protection
                                    ↓
                              Parameterized DB
```

---

## 📊 Penetration Test Summary

| Vulnerability | Severity | Status |
|---------------|----------|--------|
| SQL Injection | HIGH | ✅ Fixed |
| CSRF Attack | HIGH | ✅ Fixed |
| Brute Force | MEDIUM | ✅ Mitigated |
| Missing Headers | LOW | ✅ Fixed |
| Info Disclosure | LOW | ✅ Fixed |

---

*Repository maintained by Cybersecurity Intern · Deadline: April 28, 2026*
